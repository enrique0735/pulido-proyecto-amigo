import React from 'react';
import { useLocation } from 'wouter';
import { ArrowLeft, Bell } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { ThemeToggleButton } from "@/components/ui/theme-toggle";
import { useAuth } from '@/hooks/useAuth';

interface SimpleLayoutProps {
  children: React.ReactNode;
  title: string;
  backUrl: string;
}

// Diseño simplificado sin menú lateral para páginas específicas
export default function SimpleLayout({ children, title, backUrl }: SimpleLayoutProps) {
  const [, navigate] = useLocation();
  const { user, isAuthenticated } = useAuth();

  if (!isAuthenticated) {
    window.location.href = '/login';
    return null;
  }

  return (
    <div className="flex flex-col h-screen bg-gray-100 dark:bg-gray-900">
      {/* Encabezado simplificado */}
      <header className="bg-white dark:bg-gray-800 shadow">
        <div className="px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Button 
              variant="ghost" 
              onClick={() => navigate(backUrl)}
              className="flex items-center"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Volver
            </Button>
            <h1 className="text-xl font-semibold text-gray-700 dark:text-gray-300">{title}</h1>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <ThemeToggleButton />
              <Button variant="outline" size="icon">
                <Bell size={18} />
              </Button>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center">
                {user?.profileImageUrl ? (
                  <img
                    src={user.profileImageUrl}
                    alt="Profile"
                    className="w-full h-full rounded-full object-cover"
                  />
                ) : (
                  <span className="text-sm font-medium">
                    {user?.firstName?.[0] || user?.username?.[0] || "U"}
                  </span>
                )}
              </div>
              <div className="hidden md:block">
                <div className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  {user?.firstName} {user?.lastName}
                </div>
                <div className="text-xs text-gray-500 dark:text-gray-400">{user?.role}</div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Contenido principal */}
      <main className="flex-1 overflow-auto bg-gray-50 dark:bg-gray-800 p-4">
        {children}
      </main>
    </div>
  );
}