import React from "react";
import NotificationDropdown from "../common/NotificationDropdown";
import { Menu, Settings, HelpCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

interface TopBarProps {
  toggleSidebar: () => void;
  title: string;
}

const TopBar: React.FC<TopBarProps> = ({ toggleSidebar, title }) => {
  return (
    <header className="bg-white h-16 shadow-sm flex items-center px-4 z-10">
      <Button
        variant="ghost"
        size="icon"
        className="md:hidden mr-4"
        onClick={toggleSidebar}
        aria-label="Toggle sidebar"
      >
        <Menu className="h-5 w-5" />
      </Button>
      
      <h1 className="text-lg font-semibold text-neutral flex-1">{title}</h1>
      
      {/* Top Bar Actions */}
      <div className="flex items-center space-x-4">
        {/* Notifications */}
        <NotificationDropdown />
        
        {/* Settings */}
        <Button variant="ghost" size="icon" className="p-1 rounded-full hover:bg-gray-100">
          <Settings className="h-5 w-5 text-neutral" />
        </Button>
        
        {/* Help */}
        <Button variant="ghost" size="icon" className="p-1 rounded-full hover:bg-gray-100">
          <HelpCircle className="h-5 w-5 text-neutral" />
        </Button>
      </div>
    </header>
  );
};

export default TopBar;
