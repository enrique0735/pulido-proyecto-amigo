import React, { useState } from 'react';
import { Link, useLocation } from 'wouter';
import {
  LayoutDashboard, Bell, Menu, ChevronLeft, Users, Calendar, FileBarChart,
  AlertTriangle, SendToBack, Shield, LogOut, X, Settings, MonitorPlay, Map, Laptop,
  MessageCircle
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { ThemeToggleButton } from "@/components/ui/theme-toggle";
import { useAuth } from '@/hooks/useAuth';
import { UserRole } from '@/lib/constants';

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [location] = useLocation();
  const { user, isAuthenticated } = useAuth();

  const navigation = [
    { name: 'Gestión de Alarmas', href: '/alarms', icon: AlertTriangle, roles: [UserRole.ADMIN, UserRole.DIRECTOR, UserRole.ALARM_OPERATOR] },
    { name: 'Centro de Despacho', href: '/dispatch', icon: SendToBack, roles: [UserRole.ADMIN, UserRole.DIRECTOR, UserRole.DISPATCHER] },
    { name: 'Supervisores Motorizados', href: '/supervisors', icon: Shield, roles: [UserRole.ADMIN, UserRole.DIRECTOR, UserRole.ALARM_OPERATOR, UserRole.DISPATCHER] },
    { name: 'Gestión de Turnos', href: '/shift-scheduling', icon: Calendar, roles: [UserRole.ADMIN, UserRole.DIRECTOR, UserRole.ALARM_OPERATOR] },
    { name: 'Usuarios', href: '/user-management', icon: Users, roles: [UserRole.ADMIN, UserRole.DIRECTOR, UserRole.DISPATCHER] },
    { name: 'Reportes', href: '/reports', icon: FileBarChart, roles: [UserRole.ADMIN, UserRole.DIRECTOR, UserRole.DISPATCHER] },
    { name: 'Plataforma de Monitoreo', href: 'https://monitoreo.miscuentas24hs.com/', icon: MonitorPlay, roles: [UserRole.ADMIN, UserRole.DIRECTOR, UserRole.ALARM_OPERATOR, UserRole.DISPATCHER], external: true },
    { name: 'Rastreo GPS', href: 'https://teleguardia.fulltrackapp.com/', icon: Map, roles: [UserRole.ADMIN, UserRole.DIRECTOR, UserRole.ALARM_OPERATOR], external: true },
    { name: 'ProTrack365', href: 'https://www.protrack365.com/', icon: Laptop, roles: [UserRole.ADMIN, UserRole.DIRECTOR, UserRole.ALARM_OPERATOR], external: true },
    { name: 'WhatsApp Web', href: 'https://web.whatsapp.com/', icon: MessageCircle, roles: [UserRole.ADMIN, UserRole.DIRECTOR, UserRole.ALARM_OPERATOR, UserRole.DISPATCHER], external: true },
    { name: 'Configuración', href: '/settings', icon: Settings, roles: [UserRole.ADMIN, UserRole.DIRECTOR, UserRole.ALARM_OPERATOR, UserRole.DISPATCHER] },
  ];

  if (!isAuthenticated) {
    // Redireccionar al login si no está autenticado
    window.location.href = '/login';
    return null;
  }

  const filteredNavigation = navigation.filter(
    item => item.roles.includes(user?.role as string)
  );

  const { logout } = useAuth();
  
  const handleLogout = () => {
    // Usar directamente la página dedicada de logout en lugar de la función
    window.location.href = '/logout';
  };

  return (
    <div className="flex h-screen bg-gray-100 dark:bg-gray-900">
      {/* Sidebar para dispositivos móviles */}
      <div
        className={`${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        } fixed inset-y-0 left-0 z-50 w-64 bg-gray-900 text-white transition-transform duration-300 ease-in-out md:relative md:translate-x-0 flex flex-col`}
      >
        <div className="flex items-center justify-between p-4 border-b border-gray-800">
          <h1 className="text-xl font-bold">Despacho de Patrullas</h1>
          <button
            onClick={() => setSidebarOpen(false)}
            className="md:hidden text-white"
          >
            <X size={24} />
          </button>
        </div>

        <nav className="mt-5 px-2 flex-grow overflow-y-auto pb-16">
          <ul className="space-y-2">
            {filteredNavigation.map((item) => (
              <li key={item.name}>
                {item.external ? (
                  <a 
                    href={item.href} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className={`flex items-center px-4 py-3 text-gray-300 rounded-lg hover:bg-gray-800 hover:text-white`}
                  >
                    <item.icon className="w-5 h-5 mr-3" />
                    <span>{item.name}</span>
                  </a>
                ) : item.href === '/shift-scheduling' ? (
                  <div className="relative group">
                    <Link href={item.href}>
                      <div
                        className={`flex items-center px-4 py-3 text-gray-300 rounded-lg hover:bg-gray-800 hover:text-white ${
                          location === item.href || location === '/weekly-schedule'
                            ? "bg-gray-800 text-white"
                            : ""
                        }`}
                      >
                        <item.icon className="w-5 h-5 mr-3" />
                        <span>{item.name}</span>
                      </div>
                    </Link>
                    <div className="absolute left-0 top-full mt-1 hidden group-hover:block z-50 w-full">
                      <div className="bg-gray-900 p-2 rounded shadow-md">
                        <Link href="/shift-scheduling">
                          <div className="block px-4 py-2 text-sm text-gray-300 hover:bg-gray-800 hover:text-white rounded whitespace-nowrap">
                            Vista Mensual
                          </div>
                        </Link>
                        <Link href="/weekly-schedule">
                          <div className="block px-4 py-2 text-sm text-gray-300 hover:bg-gray-800 hover:text-white rounded whitespace-nowrap">
                            Vista Semanal
                          </div>
                        </Link>
                      </div>
                    </div>
                  </div>
                ) : (
                  <Link href={item.href}>
                    <div
                      className={`flex items-center px-4 py-3 text-gray-300 rounded-lg hover:bg-gray-800 hover:text-white ${
                        location === item.href
                          ? "bg-gray-800 text-white"
                          : ""
                      }`}
                    >
                      <item.icon className="w-5 h-5 mr-3" />
                      <span>{item.name}</span>
                    </div>
                  </Link>
                )}
              </li>
            ))}
          </ul>
        </nav>

        <div className="sticky bottom-0 w-full border-t border-gray-800 p-4 bg-gray-900">
          <button
            onClick={handleLogout}
            className="flex items-center w-full px-4 py-2 text-gray-300 rounded-lg hover:bg-gray-800 hover:text-white"
          >
            <LogOut className="w-5 h-5 mr-3" />
            <span>Cerrar Sesión</span>
          </button>
        </div>
      </div>

      {/* Contenido principal */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="bg-white dark:bg-gray-800 shadow">
          <div className="px-4 py-3 flex items-center justify-between">
            <button
              onClick={() => setSidebarOpen(true)}
              className="md:hidden text-gray-600"
            >
              <Menu size={24} />
            </button>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <ThemeToggleButton />
                <Button variant="outline" size="icon">
                  <Bell size={18} />
                </Button>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center">
                  {user?.profileImageUrl ? (
                    <img
                      src={user.profileImageUrl}
                      alt="Profile"
                      className="w-full h-full rounded-full object-cover"
                    />
                  ) : (
                    <span className="text-sm font-medium">
                      {user?.firstName?.[0] || user?.username?.[0] || "U"}
                    </span>
                  )}
                </div>
                <div className="hidden md:block">
                  <div className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    {user?.firstName} {user?.lastName}
                  </div>
                  <div className="text-xs text-gray-500 dark:text-gray-400">{user?.role}</div>
                </div>
              </div>
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-auto bg-gray-50 dark:bg-gray-800 p-4">{children}</main>
      </div>
    </div>
  );
}