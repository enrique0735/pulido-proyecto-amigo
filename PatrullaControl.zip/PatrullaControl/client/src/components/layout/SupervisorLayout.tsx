import React from 'react';
import { LogOut, Map, FileBarChart, Laptop, MessageCircle, MonitorPlay } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { useLocation } from 'wouter';

interface SupervisorLayoutProps {
  children: React.ReactNode;
}

// Layout especial para supervisores sin menú lateral completo, solo con botones específicos
export default function SupervisorLayout({ children }: SupervisorLayoutProps) {
  const [, navigate] = useLocation();
  
  const handleLogout = () => {
    // Usar directamente la página dedicada de logout
    window.location.href = '/logout';
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-[#001428] to-black">
      {/* Header minimalista */}
      <header className="bg-black/40 backdrop-blur-md border-b border-blue-500/20 p-4 flex justify-between items-center">
        <div>
          <h1 className="text-xl font-bold text-white">Panel de Supervisor</h1>
          <p className="text-sm text-blue-400">Sistema de control de patrullas</p>
        </div>
        
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="icon"
            onClick={handleLogout}
            className="border border-blue-500/30 bg-blue-950/30 text-blue-300 hover:bg-blue-900/50 hover:text-blue-200"
          >
            <LogOut className="h-5 w-5" />
          </Button>
        </div>
      </header>
      
      {/* Contenido principal */}
      <main className="container mx-auto py-6 px-4 h-[calc(100vh-72px)] overflow-auto">
        {children}
      </main>
    </div>
  );
}