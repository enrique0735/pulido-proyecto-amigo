import React from "react";
import { Link, useLocation } from "wouter";
import { navigationItems } from "@/lib/navigationItems";
import { getFullName, getRoleDisplay, AuthUser } from "@/lib/auth";
import { LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  user: AuthUser | null;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose, user }) => {
  const [location] = useLocation();
  const { logout } = useAuth();

  // Filter navigation items based on user role
  const filteredNavItems = user 
    ? navigationItems.filter(item => {
        // Necesitamos asegurarnos de que user.role coincida con uno de los roles permitidos
        return item.roles.some(role => role === user.role);
      })
    : [];

  const handleLogout = () => {
    logout();
  };

  return (
    <div 
      className={`sidebar bg-white w-64 h-full shadow-md flex flex-col z-10 fixed md:relative transition-transform duration-300 ease-in-out ${
        isOpen ? "transform-none" : "transform -translate-x-full md:transform-none"
      }`}
    >
      {/* Header with Logo */}
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center">
          <div className="w-10 h-10 bg-primary-800 rounded-lg flex items-center justify-center mr-3">
            <span className="material-icons text-white">security</span>
          </div>
          <div>
            <h1 className="text-lg font-bold text-neutral">SeguriPatrol</h1>
            <p className="text-xs text-gray-600">Sistema de Despacho</p>
          </div>
        </div>
      </div>
      
      {/* User Profile Section */}
      {user && (
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center">
            {user.profileImageUrl ? (
              <img
                src={user.profileImageUrl}
                alt="Foto de perfil"
                className="w-10 h-10 rounded-full object-cover mr-3"
              />
            ) : (
              <div className="w-10 h-10 rounded-full bg-primary-100 text-primary-800 flex items-center justify-center mr-3">
                <span className="material-icons">person</span>
              </div>
            )}
            <div>
              <p className="text-sm font-medium text-neutral">{getFullName(user)}</p>
              <p className="text-xs text-gray-600">{getRoleDisplay(user.role)}</p>
            </div>
          </div>
        </div>
      )}
      
      {/* Navigation Links */}
      <nav className="flex-1 overflow-y-auto p-2">
        <ul>
          {filteredNavItems.map((item) => (
            <li key={item.path} className="mb-1">
              <Link href={item.path}>
                <a
                  className={`sidebar-item flex items-center px-4 py-3 text-sm font-medium rounded-md hover:bg-gray-100 ${
                    location === item.path
                      ? "active border-l-4 border-primary-800 bg-blue-50 text-primary-800"
                      : "text-neutral"
                  }`}
                  onClick={() => {
                    if (window.innerWidth < 768) {
                      onClose();
                    }
                  }}
                >
                  <span className={`material-icons mr-3 ${location === item.path ? "text-primary-800" : "text-primary-700"}`}>
                    {item.icon}
                  </span>
                  {item.name}
                </a>
              </Link>
            </li>
          ))}
        </ul>
      </nav>
      
      {/* Logout Option */}
      <div className="p-4 border-t border-gray-200">
        <Button
          variant="ghost"
          className="flex items-center w-full px-4 py-2 text-sm font-medium text-neutral rounded-md hover:bg-gray-100"
          onClick={handleLogout}
        >
          <LogOut className="h-4 w-4 mr-2" />
          Cerrar Sesión
        </Button>
      </div>
    </div>
  );
};

export default Sidebar;
