import React, { useState } from "react";
import { useNotifications } from "@/hooks/useNotifications";
import { format, formatDistanceToNow } from "date-fns";
import { es } from "date-fns/locale";

interface NotificationDropdownProps {
  className?: string;
}

const NotificationDropdown: React.FC<NotificationDropdownProps> = ({ className }) => {
  const [isOpen, setIsOpen] = useState(false);
  const { notifications, count, markAsRead, markAllAsRead } = useNotifications();

  const toggleDropdown = () => {
    setIsOpen(!isOpen);
  };

  const handleClickOutside = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      setIsOpen(false);
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "alarm":
        return <span className="material-icons text-danger mr-3">warning</span>;
      case "patrol":
        return <span className="material-icons text-secondary-500 mr-3">local_shipping</span>;
      case "system":
        return <span className="material-icons text-primary-700 mr-3">info</span>;
      case "success":
        return <span className="material-icons text-success mr-3">check_circle</span>;
      default:
        return <span className="material-icons text-neutral mr-3">notifications</span>;
    }
  };

  const getTimeAgo = (dateString: string) => {
    try {
      const date = new Date(dateString);
      return formatDistanceToNow(date, { addSuffix: true, locale: es });
    } catch (error) {
      return "Fecha desconocida";
    }
  };

  const handleNotificationClick = (id: number) => {
    markAsRead(id);
  };

  const handleMarkAllAsRead = () => {
    markAllAsRead();
    setIsOpen(false);
  };

  return (
    <div className={`relative ${className}`}>
      <button 
        className="relative p-1 rounded-full hover:bg-gray-100" 
        onClick={toggleDropdown}
        aria-label="Notifications"
      >
        <span className="material-icons text-neutral">notifications</span>
        {count > 0 && (
          <span className="absolute top-0 right-0 bg-danger text-white text-xs w-5 h-5 flex items-center justify-center rounded-full">
            {count > 99 ? "99+" : count}
          </span>
        )}
      </button>
      
      {isOpen && (
        <div 
          className="fixed inset-0 z-40 bg-transparent"
          onClick={handleClickOutside}
        >
          <div 
            className="absolute right-0 mt-2 w-72 bg-white rounded-md shadow-lg overflow-hidden z-20"
            style={{ top: "100%", right: "0" }}
          >
            <div className="p-3 border-b border-gray-200">
              <h3 className="text-sm font-semibold text-neutral">Notificaciones</h3>
            </div>
            <div className="max-h-64 overflow-y-auto">
              {notifications && notifications.length > 0 ? (
                notifications.map((notification) => (
                  <div 
                    key={notification.id}
                    className={`p-3 border-b border-gray-100 hover:bg-gray-50 ${!notification.read ? 'bg-blue-50' : ''}`}
                    onClick={() => handleNotificationClick(notification.id)}
                  >
                    <div className="flex">
                      {getNotificationIcon(notification.type)}
                      <div>
                        <p className="text-sm font-medium text-neutral">{notification.title}</p>
                        <p className="text-xs text-gray-500">{getTimeAgo(notification.createdAt)}</p>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-3 text-center text-sm text-gray-500">
                  No hay notificaciones
                </div>
              )}
            </div>
            <div className="p-2 border-t border-gray-200">
              <button 
                className="w-full text-xs text-primary-700 p-2 hover:bg-gray-50 rounded"
                onClick={handleMarkAllAsRead}
              >
                Marcar todas como leídas
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default NotificationDropdown;
