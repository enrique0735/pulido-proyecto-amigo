Este directorio contiene los archivos de sonido para las notificaciones del sistema.

Para implementar completamente esta funcionalidad, deberás añadir aquí los siguientes archivos:

1. notification.mp3 - Sonido breve para notificaciones generales
2. alarm.mp3 - Sonido de alarma para alertas urgentes

Estos archivos deben ser accesibles desde la ruta "/sounds/notification.mp3" y "/sounds/alarm.mp3" respectivamente.